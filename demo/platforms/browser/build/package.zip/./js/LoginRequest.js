'use strict';


function LoginRequest(username, password) {


    this.username = username;

    this.password = password;


}
