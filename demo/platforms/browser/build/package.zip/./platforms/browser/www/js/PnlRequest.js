'use strict';


function PnlRequest(passwordNumber, passengerFullName) {


    this.passwordNumber = passwordNumber;

    this.passengerFullName = passengerFullName;


}
